$(document).ready(function() {
    $(".padel-nav").click(function() {
        if (($(this).attr("aria-selected") == "false")) {
            var $padelnav = $(".padel-nav"),
                $slidepanels = $('.slide-panel'),
                _index = $padelnav.index(this);
            $padelnav.attr("aria-selected", "false").attr("tabindex", "-1");
            $padelnav.eq(_index).attr("aria-selected", "true").attr("tabindex", "0");
            $padelnav.eq(_index).addClass("focus");
            $slidepanels.hide().attr("aria-hidden", "true");
            var tabpanid = $padelnav.eq(_index).attr("aria-controls");
            $("#" + tabpanid).removeAttr('aria-hidden').show();
            managePaddleNav();
        }
        return false;
    });

    //This adds keyboard function that pressing an arrow left or arrow right from the tabs toggel the tabs. 
    $(".padel-nav").keydown(function(ev) {
        var keyCode = ev.which;
        var _this = ev.target;

        var $padelnav = $(".padel-nav"),
            $slidepanels = $('.slide-panel'),
            $current = $padelnav.filter('.focus'),
            _index = $padelnav.index($current),
            prevItemIndex = _index;

        switch (keyCode) {
            case 37: //left-arrow
            case 38: //up-arrow
                if (_index > 0) {
                    prevItemIndex = _index - 1;
                    $padelnav.removeClass("focus");
                    $padelnav.eq(prevItemIndex).addClass("focus");
                    $padelnav.eq(prevItemIndex).focus();
                    managePaddleNav();

                }
                ev.preventDefault();
                ev.stopPropagation();

                break;
            case 39: //right-arrow
            case 40: //down-arrow
                if (_index != $padelnav.length - 1) {
                    nextItemIndex = _index + 1;
                    $padelnav.removeClass("focus");
                    $padelnav.eq(nextItemIndex).addClass("focus");
                    $padelnav.eq(nextItemIndex).focus();
                    managePaddleNav();
                }
                ev.preventDefault();
                ev.stopPropagation();
                break;
            case 13: //Enter
            case 32: //Space
                ev.preventDefault();
                ev.stopPropagation();
                _this.click();
                break;
            default:
                break;
        }
    });

    $("#previous").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();
        var $padelnav = $(".padel-nav"),
            $slidepanels = $('.slide-panel'),
            $current = $padelnav.filter('[aria-selected="true"]'),
            _index = $padelnav.index($current),
            prevItemIndex = _index;
        if (_index > 0) {
            prevItemIndex = _index - 1;
        } else {
            prevItemIndex = $padelnav.length - 1;
        }
        $padelnav.eq(prevItemIndex).click();


        $current = $padelnav.filter('[aria-selected="true"]');
        _index = $padelnav.index($current);

        if (_index == 0) {
            $("#next").focus();
        }
    });

    $("#next").on("click", function(e) {
        e.preventDefault();
        e.stopPropagation();

        var $this = $(this),
            $padelnav = $(".padel-nav"),
            $current = $padelnav.filter('[aria-selected="true"]'),
            _index = $padelnav.index($current),
            nextItemIndex = _index;
        if (_index != $padelnav.length - 1) {
            nextItemIndex = _index + 1;
        } else {
            nextItemIndex = 0;
        }
        $padelnav.eq(nextItemIndex).click();


        $current = $padelnav.filter('[aria-selected="true"]');
        _index = $padelnav.index($current);

        if (_index == $padelnav.length - 1) {
            $("#previous").focus();
        }
    });


    managePaddleNav = function() {

        var $padelnav = $(".padel-nav"),
            $current = $padelnav.filter('[aria-selected="true"]'),
            _index = $padelnav.index($current);
        if (_index === 0) {
            $("#previous").hide();
        } else if (_index == $padelnav.length - 1) {
            $("#next").hide();
        } else {
            $("#previous").show();
            $("#next").show();
        }
    }
    managePaddleNav();
});