$(document).ready(function() {
    console.log("Document loaded fully and it is ready to manipulate.");
    var $trigger = $('.tooltip-trigger'),
        $details = $('.tooltip-details'),
        $doc = $(document);
    $trigger.on('focus', function(e) {
        e.preventDefault();
        $details = $(this).parent().find(".tooltip-details");
        return (!$details.is(":visible")) ? openTooltip() : false;
    });
    $trigger.on('blur', function(e) {
        e.preventDefault();
        $details = $(this).parent().find(".tooltip-details");
        return ($details.is(':visible')) ? closeTooltip() : false;
    });
    $trigger.on('mouseover', function(e) {
        closeAll();
        e.preventDefault();
        $details = $(this).parent().find(".tooltip-details");
        return (!$details.is(':visible')) ? openTooltip() : false;
    });
    $trigger.on('mouseout', function mouseOut(e) {
        e.preventDefault();
        closeAll();
        $details = $(this).parent().find(".tooltip-details");
        return (!$(this).is(':focus')) ? closeTooltip() : false;
    });

    function openTooltip() {
        $details.show();
        $doc.on('keydown.hideTooltip', keylistner);
        $doc.on('keydown', keylistner);
    }

    function closeTooltip() {
        $details.hide();
        $doc.off('.hideTooltip');
    }

    function closeAll() {
        $(document).find(".tooltip-details").hide();
    }

    function keylistner(e) {
        return (e.which === 27 && $details.is(':visible')) ? closeTooltip() : true;
    }
});