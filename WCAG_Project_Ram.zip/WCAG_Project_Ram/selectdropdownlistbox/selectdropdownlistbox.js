$(document).ready(function() {
    console.log("Document loaded fully and it is ready to manipulate.");
    let $doc = $(document);
    let $trigger = $("#dropdown-trigger");
    let $dropdowncontainer = $("#dropdown-container");
    let $menuitem = $(".menuitem");
    let keys = Object.freeze({
        ENTER: 13,
        SPACE: 32,
        LEFT_ARROW: 37,
        UP_ARROW: 38,
        RIGHT_ARROW: 39,
        DOWN_ARROW: 40,
        ESCAPE: 27

    });
    var methods = {
        showContainer: function() {
            // $trigger.attr("aria-haspopup", "true");
            $trigger.addClass("expanded").attr("aria-expanded", "true");
            $dropdowncontainer.show();
            // this.setFocusToTrigger();
            methods.bindDropdownEvents(); //Add event listeners on the DOM
        },
        hideContainer: function() {
            // $trigger.attr("aria-haspopup", "menu");
            $trigger.removeClass("expanded").attr("aria-expanded", "false");
            $dropdowncontainer.hide();
            // this.setFocusToTrigger();
            $doc.off("." + $trigger[0].id) // Remove event listeners on the DOM
        },
        setFocusToTrigger: function() {
            window.setTimeout(function() {
                $trigger.focus();
            })
        },
        setAriaAttributesItems: function(node) {
            $menuitem.find("span[role='menuitemradio']").attr("aria-checked", "false");
            node.find("span[role='menuitemradio']").attr("aria-checked", "true");
        },
        setRovingTabindex: function(node) {
            $menuitem.attr("tabindex", "-1");
            node.attr("tabindex", "0");
        },
        moveFocusToNextItem: function(node) {
            if (node.next().length > 0) {
                node.next().focus();
            } else {
                return false;
            }

        },
        moveFocusToPrevItem: function(node) {
            if (node.prev().length > 0) {
                node.prev().focus();
            } else {
                return false;
            }
        },
        setFirstOrPreviousSelectedItemFocus: function() {
            let list = $dropdowncontainer.find(".menuitem[tabindex='0']");
            if (list.length === 0) {
                $dropdowncontainer.find(".menuitem:first").focus();
            } else {
                $dropdowncontainer.find(".menuitem[tabindex='0']").focus();
            }
        },
        bindDropdownEvents: function() {
            let namespace = $trigger[0].id; // event.namespace is used to determine the specific dropdown in entire DOM.
            $doc.on("click." + namespace, events.docDismiss);
            $doc.on("focusin." + namespace, events.focusOutside);
            $doc.on("keydown." + namespace, events.escapeDismiss);
        }
    }
    var events = {
        toggleContainer: function(e) {
            e.preventDefault();
            e.stopPropagation();
            return ($(this).hasClass("expanded")) ? methods.hideContainer() : methods.showContainer();
        },
        keydownToggle: function(e) {
            switch (e.which) {
                case keys.UP_ARROW:
                    return ($dropdowncontainer.is(":visible")) ? methods.hideContainer() : true;
                case keys.DOWN_ARROW:
                    return ($dropdowncontainer.is(":visible")) ? methods.setFirstOrPreviousSelectedItemFocus() : methods.showContainer();
            }
        },
        menuitemClick: function(e) {
            $trigger.find(".dropdown-trigger-text").text($(this).text());
            methods.setAriaAttributesItems($(this));
            methods.setRovingTabindex($(this));
            methods.hideContainer();
            methods.setFocusToTrigger();
            return false;
        },
        keydownMenuitem: function(e) {
            let currentCheckedItem = $(this);
            switch (e.which) {
                case keys.SPACE:
                case keys.ENTER:
                    e.preventDefault();
                    e.stopPropagation();
                    $(this).click();
                    break;
                case keys.DOWN_ARROW:
                    methods.moveFocusToNextItem(currentCheckedItem);
                    break;
                case keys.UP_ARROW:
                    methods.moveFocusToPrevItem(currentCheckedItem);
                    break;
            }
        },
        docDismiss: function(e) {
            let $currentTarget = $(e.target);
            return ($currentTarget.closest($dropdowncontainer).length === 0 && !$currentTarget.is($dropdowncontainer)) ? methods.hideContainer() : false;

        },
        focusOutside: function(e) {
            let $currentTarget = $(e.target);
            return ($currentTarget.closest($dropdowncontainer).length === 0 && !$currentTarget.is($trigger)) ? methods.hideContainer() : false;
        },
        escapeDismiss: function(e) {
            if (e.which === keys.ESCAPE) {
                methods.setFocusToTrigger();
                methods.hideContainer();
            } else {
                return true;
            }
        }
    }
    $trigger.on("click", events.toggleContainer);
    $trigger.on("keydown", events.keydownToggle);
    $dropdowncontainer.on("click", ".menuitem", events.menuitemClick);
    $dropdowncontainer.on("keydown", ".menuitem", events.keydownMenuitem);
});