function modifyCheckBox(event) {
    let item = document.getElementById(event.target.id);
    if (event.keyCode === 32 || event.type === "click") {
        switch (item.getAttribute('aria-checked')) {
            case "true":
                item.setAttribute('aria-checked', "false");
                event.preventDefault();
                event.stopPropagation();
                break;
            case "false":
                item.setAttribute('aria-checked', "true");
                event.preventDefault();
                event.stopPropagation();
                break;
        }
    }
}