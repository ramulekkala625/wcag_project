$(document).ready(function() {
    var triggeElement;
    var focusableElements = "a[href], area[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), iframe, object, embed, *[tabindex], *[contenteditable]";
    var tabindexElements = "*[tabindex]";
    var $content = $('main');
    var $modalopener = $("#modal-opener");
    var $modalOverlay = $(".overlay");
    var $modal = $(".modal");
    var $closeicon = $("#close_icon");

    $modalopener.on("click", function() {
        triggeElement = $(this);
        showModal();
        return false;
    });

    $modalopener.on("keydown", function(e) {
        var kayCode = e.which;
        switch (kayCode) {
            case 13:
            case 32:
                triggeElement = $(this);
                showModal();
                return false;
            default:
                break;
        }
    });

    $closeicon.on("keydown", function(e) {
        var kayCode = e.which;
        switch (kayCode) {
            case 13:
            case 32:
                closeModal(triggeElement);
                return false;
            default:
                break;
        }
    });
    $closeicon.on("click", function() {
        closeModal(triggeElement);
        return false;
    });
    $modalOverlay.on("click", function() {
        closeModal(triggeElement);
        return false;
    });

    $modal.on("keydown", function(event) {
        escKeyManage(triggeElement, event);
    });

    $(document).on("keydown", function(event) {
        if ($(this).find(".modal").is(":visible")) {
            escKeyManage(triggeElement, event);
        }
    });

    function escKeyManage(triggeElement, eevent) {
        if (event.keyCode == 27) {
            closeModal(triggeElement);
        }
    }

    function showModal() {
        $content.attr("aria-hidden", "true"); //setting aria-hidden='true' for skipping VO users
        storeTabindex(); //storing tabindex values in datatabiondex
        $content.find(focusableElements).attr('tabindex', '-1'); //setting tabindex='-1' to all the interactive elements, so that keyboard tab focus will get to all the interactive elements.
        $modalOverlay.show();
        $modal.show();


        setTimeout(function() {
            $modal.focus(); //after modal opened, we have to set focus to modal container.
            $modal.removeAttr("tabindex");
        }, 50);
    }

    function closeModal(triggeElement) {
        $modal.hide();
        $modalOverlay.hide();
        $content.removeAttr("aria-hidden");
        $content.find(focusableElements).removeAttr('tabindex');
        setTimeout(function() {
            triggeElement.focus();
            $modal.attr("tabindex", "-1");
            reStoreTabindex(); //re-storing tabindex values from datatabiondex
        }, 50);
    }

    function storeTabindex() {
        $content.find(tabindexElements).each(function(index) {
            $(this).attr("datatabindex", $(this).attr("tabindex"))
        })
    }

    function reStoreTabindex() {
        $content.find('[datatabindex]').each(function(index) {
            $(this).attr("tabindex", $(this).attr("datatabindex"));
            $(this).removeAttr("datatabindex");
        })
    }

});