$(document).ready(function() {
    console.log("Document loaded fully and it is ready to manipulate.");
    $('.deleteButton').on('click', function(e) {
        var button_length = $('.deleteButton').length;
        var next_li = $(this).parent('li').next();
        var prev_li = $(this).parent('li').prev();
        var current_li = next_li.length > 0 ? next_li : prev_li;
        if (button_length === 1) {
            $(this).parent('li').remove();
            $('ul').append('<li role="listitem" tabindex="-1" id="no-more">No results</li>');
            $("#no-more").focus();
        } else {
            current_li.find('.deleteButton').focus();
            $(this).parent('li').remove();
        }
    })
});