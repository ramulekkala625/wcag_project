$(document).ready(function() {
    console.log("Document loaded fully and it is ready to manipulate.");
    let $listbox = $(".listbox");
    let $listboxoptions = $(".listbox .option");
    let isFocused = false;
    let keys = Object.freeze({
        ENTER: 13,
        SPACE: 32,
        END: 35,
        HOME: 36,
        LEFT_ARROW: 37,
        UP_ARROW: 38,
        RIGHT_ARROW: 39,
        DOWN_ARROW: 40,
        LETTERS_STARTS_FROM: 65,
        LETTERS_ENDS_FROM: 90,
    });
    $listbox.on("focusin", function() {
        if (isFocused == false) {
            isFocused = true;
            $(this).addClass("focused");
        }
    });
    $listbox.on("focusout", function() {
        if (isFocused == true) {
            isFocused = false;
            $(this).removeClass("focused");
        }
    });
    $listboxoptions.on("click", function() {
        $listboxoptions.attr("aria-selected", "false");
        if (isFocused == false) {
            isFocused = true;
            $listbox.focus();
            $listbox.addClass("focused");
        }
        $(this).attr("aria-selected", "true");
        // $(this).closest(".listbox").attr("aria-activedescendant", $(this).attr("id"))
        updateActivedescendant($(this).attr("id"));
    });

    $listbox.on("keydown", function(e) {
        let currentSelected = $(this).find("[aria-selected='true']");
        let keyCode = e.keyCode;
        if (keyCode == keys.UP_ARROW) {
            moveSelectionToPreviousItem(currentSelected)
            e.preventDefault();
        } else if (keyCode === keys.DOWN_ARROW) {
            moveSelectionToNextItem(currentSelected)
            e.preventDefault();
        } else if (keyCode === keys.LEFT_ARROW || keyCode === keys.RIGHT_ARROW) {
            e.preventDefault();
        } else if (keyCode >= keys.LETTERS_STARTS_FROM && keyCode <= keys.LETTERS_ENDS_FROM) {
            var enteredLetter = String.fromCharCode(keyCode);
            moveSelectionToEnteredLetter(enteredLetter);
        } else if (keyCode === keys.HOME) {
            moveSelectionToFirstItem(currentSelected);
            e.preventDefault();
        } else if (keyCode == keys.END) {
            moveSelectionToLastItem(currentSelected);
            e.preventDefault();
        }
    });

    function moveSelectionToNextItem(nodeListObj) {

        if (nodeListObj.next().length > 0) {
            nodeListObj.attr("aria-selected", "false");
            nodeListObj.next().attr("aria-selected", "true");
            updateActivedescendant(nodeListObj.next().attr("id"));
        } else {
            return false;
        }

    }

    function moveSelectionToPreviousItem(nodeListObj) {

        if (nodeListObj.prev().length > 0) {
            nodeListObj.attr("aria-selected", "false");
            nodeListObj.prev().attr("aria-selected", "true");
            updateActivedescendant(nodeListObj.prev().attr("id"));
        } else {
            return false;
        }
    }

    function moveSelectionToFirstItem(nodeListObj) {
        let $firstOption = $listbox.children().first();
        nodeListObj.attr("aria-selected", "false");
        $firstOption.attr("aria-selected", "true");
        updateActivedescendant($firstOption.attr("id"));
    }

    function moveSelectionToLastItem(nodeListObj) {
        let $lastOption = $listbox.children().last();
        nodeListObj.attr("aria-selected", "false");
        $lastOption.attr("aria-selected", "true");
        updateActivedescendant($lastOption.attr("id"));
    }

    function moveSelectionToEnteredLetter(letter) {
        let enteredChar = letter.toUpperCase();
        $listbox.children().each(function(index, element) {
            let elementsFirstLetter = $(this).text().trim().charAt(0).toUpperCase();
            if (elementsFirstLetter == enteredChar && $(this).attr("aria-selected") != "true") {
                setSelection($(this));
                return false;
            }
        });

    }

    function setSelection(nodeListObj) {
        $listboxoptions.attr("aria-selected", "false");
        nodeListObj.attr("aria-selected", "true");
        updateActivedescendant(nodeListObj.attr("id"));
    }

    function updateActivedescendant(id) {
        $listbox.attr("aria-activedescendant", id);
    }

});