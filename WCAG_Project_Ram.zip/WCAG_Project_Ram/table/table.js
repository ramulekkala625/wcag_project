$(document).ready(function() {
    console.log("Document loaded fully and it is ready to manipulate.");
});